package com.converter.controllers;

import java.io.IOException;
import java.net.MalformedURLException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathExpressionException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.xml.sax.SAXException;

import com.converter.models.Currency;
import com.converter.models.CurrencyData;
import com.converter.models.ExchangeData;
import com.converter.repositories.CurrencyRepository;
import com.converter.services.CurrencyService;
import com.converter.services.XmlDataHandler;


@Controller
public class HomeController {

  private CurrencyRepository currencyRepository;

  @Autowired
  public void setCurrencyRepository(CurrencyRepository currencyRepository) {
    this.currencyRepository = currencyRepository;
  }

  private XmlDataHandler xmlDataHandler;

  @Autowired
  public void setXmlDataHandler(XmlDataHandler xmlDataHandler) {
    this.xmlDataHandler = xmlDataHandler;
  }


  private CurrencyService currencyService;

  @Autowired
  public void setCurrencyService(CurrencyService currencyService) {
    this.currencyService = currencyService;
  }

  @RequestMapping(value="/", method = RequestMethod.GET)
  public ModelAndView index(Currency currency, ModelAndView model) throws XPathExpressionException, MalformedURLException, ParserConfigurationException, SAXException, IOException {
    model.setViewName("index");
    model.addObject("currencies", currencyService.getAllCurrencies());
    return model;
  }

  @RequestMapping("/currencies/{currencyCode}")
  public String showCurrencyData(@PathVariable("currencyCode") String currencyCode) {
    return "index";
  }

  @RequestMapping(value = "/exchange")
  public @ResponseBody String exchange(@RequestBody ExchangeData exchangeData) {
    String result = currencyService.calculateRates(exchangeData);
    return result;
  }

  @RequestMapping(value = "/graphData/{currencyCode}")
  public @ResponseBody CurrencyData getGraphData(@PathVariable String currencyCode) {
    CurrencyData result = new CurrencyData(xmlDataHandler.getAllDates(), currencyService.getAllRatesByCurrencyCode(currencyCode));
    return result;
  }

}
