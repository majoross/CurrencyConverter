package com.converter.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.converter.models.Currency;

@Repository
public interface CurrencyRepository extends CrudRepository<Currency, Long> {

  public Currency findByDateAndCurrencyCode(String date, String currencyCode);

  public Currency findByCurrencyCode(String currencyCode);

  public Currency findByRate(String rate);

  public List<String> findBydate(String date);

  public List<Currency> findAllByCurrencyCode(String currencyCode);

  @Override
  public List<Currency> findAll();

}
