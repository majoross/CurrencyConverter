package com.converter.models;

import java.util.List;

public class CurrencyData {

  public List<String> dates;
  public List<String> rates;

  public CurrencyData(List<String> dates, List<String> rates) {
    this.dates = dates;
    this.rates = rates;
  }

  public CurrencyData() {}

  public List<String> getDates() {
    return dates;
  }

  public void setDates(List<String> dates) {
    this.dates = dates;
  }

  public List<String> getRates() {
    return rates;
  }

  public void setRates(List<String> rates) {
    this.rates = rates;
  }

}
