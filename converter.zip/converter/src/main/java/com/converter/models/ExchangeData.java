package com.converter.models;

public class ExchangeData {

  String currencyHave;
  String currencyWant;

  public ExchangeData() {}

  public ExchangeData(String currencyHave, String currencyWant) {
    this.currencyHave = currencyHave;
    this.currencyWant = currencyWant;
  }

  public String getCurrencyHave() {
    return currencyHave;
  }

  public void setCurrencyHave(String currencyHave) {
    this.currencyHave = currencyHave;
  }

  public String getCurrencyWant() {
    return currencyWant;
  }

  public void setCurrencyWant(String currencyWant) {
    this.currencyWant = currencyWant;
  }

  @Override
  public String toString() {
    return "ExchangeData [currencyHave=" + currencyHave + ", currencyWant=" + currencyWant + "]";
  }

}
