package com.converter.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity(name = "currency")
public class Currency {

  @GeneratedValue
  @Id
  private Long id;

  @Column(name = "currency_code")
  private String currencyCode;

  @Column(name = "rate")
  private String rate;

  @Column(name = "date")
  private String date;

  public String getRate() {
    return rate;
  }

  public void setRate(String rate) {
    this.rate = rate;
  }

  public String getDate() {
    return date;
  }

  public void setDate(String date) {
    this.date = date;
  }

  public String getCurrencyCode() {
    return currencyCode;
  }

  public void setCurrencyCode(String currencyCode) {
    this.currencyCode = currencyCode;
  }


  public Long getId() {
    return id;
  }

  public Currency() {};

  public Currency(String currencyCode, String rate, String date) {
    this.currencyCode = currencyCode;
    this.rate = rate;
    this.date = date;
  }


}
