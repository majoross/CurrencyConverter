package com.converter.services;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.converter.models.Currency;
import com.converter.repositories.CurrencyRepository;

@Service
public class XmlDataHandler {

  private CurrencyRepository currencyRepository;


  @Autowired
  public void setCurrencyRepository(CurrencyRepository currencyRepository) {
    this.currencyRepository = currencyRepository;
  }

  private static final String xmlUrl = "http://www.ecb.europa.eu/stats/eurofxref/eurofxref-hist-90d.xml";
  List<String> dates;
  List<String> rates;
  List<String> currencies;

  private DocumentBuilderFactory dbFactory;
  private DocumentBuilder dBuilder;
  private Document doc;

  private XPathFactory xPathFactory;
  private XPath xpath;

  @PostConstruct
  public void init() throws XPathExpressionException, ParserConfigurationException, MalformedURLException, SAXException, IOException {
    dbFactory = DocumentBuilderFactory.newInstance();
    dBuilder = dbFactory.newDocumentBuilder();
    doc = dBuilder.parse(new URL(xmlUrl).openStream());
    doc.getDocumentElement().normalize();
    xPathFactory = XPathFactory.newInstance();
    xpath = xPathFactory.newXPath();
    dates = new ArrayList<>();
    rates = new ArrayList<>();
    initAllDatesFromXml();
    initAllCurrenciesFromXml();
    createCurrenciyEntities();
  }

  public void initAllDatesFromXml() throws XPathExpressionException {
    XPathExpression allDates = xpath.compile("//Cube[@time]");
    NodeList nl = (NodeList) allDates.evaluate(doc, XPathConstants.NODESET);
    for (int node = 0; node < nl.getLength(); node++) {
      dates.add(nl.item(node).getAttributes().getNamedItem("time").getNodeValue());
    }
  }

  public List<String> getAllDates() {
    return dates;
  }

  public String getLatestDate() {
    String latestDate;
    latestDate = Collections.max(dates).toString();
    return latestDate;
  }

  public void initAllCurrenciesFromXml() throws XPathExpressionException {
    currencies = new ArrayList<>();
    XPathExpression currenciesFromXml = xpath.compile("//Cube[@time=\"" + getLatestDate() + "\"]/Cube[@currency]");
    NodeList nl = (NodeList) currenciesFromXml.evaluate(doc, XPathConstants.NODESET);
    for (int node = 0; node < nl.getLength(); node++) {
      currencies.add(nl.item(node).getAttributes().getNamedItem("currency").getNodeValue());
    }
  }

  public List<String> getAllCurrencies() {
    return currencies;
  }

  public void createCurrenciyEntities() throws XPathExpressionException {
    for (int curr = 0; curr < getAllCurrencies().size(); curr++) {
      for (int date = 0; date < getAllDates().size(); date++) {
        XPathExpression currentRate = xpath.compile("//Cube[@time=\"" + getAllDates().get(date) + "\"]/Cube[@currency=\"" + getAllCurrencies().get(curr) + "\"]");
        NodeList nl = (NodeList) currentRate.evaluate(doc, XPathConstants.NODESET);
        for (int node = 0; node < nl.getLength(); node++) {
          currencyRepository.save(new Currency(getAllCurrencies().get(curr), nl.item(node).getAttributes().getNamedItem("rate").getNodeValue(), getAllDates().get(date)));
        }
      }
    }
    System.out.println(currencyRepository.findAll().toString());
  }

}
