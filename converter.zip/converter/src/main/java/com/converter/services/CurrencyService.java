package com.converter.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.converter.models.Currency;
import com.converter.models.ExchangeData;
import com.converter.repositories.CurrencyRepository;

@Service
public class CurrencyService {

  private XmlDataHandler xmlDataHandler;

  @Autowired
  public void setXmlDataHandler(XmlDataHandler xmlDataHandler) {
    this.xmlDataHandler = xmlDataHandler;
  }

  private CurrencyRepository currencyRepository;

  @Autowired
  public void setCurrencyRepository(CurrencyRepository currencyRepository) {
    this.currencyRepository = currencyRepository;
  }

  public Map<String, String> getAllCurrencies() {
    Map<String, String> currMap = new HashMap<>();
    List<Currency> currencies = currencyRepository.findAll();
    for (int currency = 0; currency < currencies.size(); currency++) {
      currMap.put(currencies.get(currency).getCurrencyCode(), currencies.get(currency).getCurrencyCode());
    }
    return currMap;
  }

  public String calculateRates(ExchangeData exchangeData) {
    Currency currHave = currencyRepository.findByDateAndCurrencyCode(xmlDataHandler.getLatestDate(), exchangeData.getCurrencyHave());
    Currency currWant = currencyRepository.findByDateAndCurrencyCode(xmlDataHandler.getLatestDate(), exchangeData.getCurrencyWant());;
    Double result = Double.parseDouble(currHave.getRate()) / Double.parseDouble(currWant.getRate());
    return result.toString();
  }

  public List<String> getAllRatesByCurrencyCode(String currencyCode) {
    List<String> rates = new ArrayList<String>();
    for (int curr = 0; curr < currencyRepository.findAllByCurrencyCode(currencyCode).size(); curr++) {
      rates.add(currencyRepository.findAllByCurrencyCode(currencyCode).get(curr).getRate());
    }
    return rates;
  }
}
