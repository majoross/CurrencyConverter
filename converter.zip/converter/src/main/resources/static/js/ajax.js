$(document).ready(function() {
  exchange();
})

function exchange(){

  var exchangeData = {
    currencyHave: $('#currencyHaveSelect option:selected').text(),
    currencyWant: $('#currencyWant option:selected').text()
  }

  $.ajax({
    type: 'POST',
    contentType: 'application/json',
    url: '/exchange',
    data: JSON.stringify(exchangeData),
    dataType: 'json',
    success: function(result) {
      $('#result').html(result);
    },

  });
}

